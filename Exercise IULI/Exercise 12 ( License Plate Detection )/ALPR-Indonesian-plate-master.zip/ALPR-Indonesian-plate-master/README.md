# ALPR-Indonesian-plate
This code is for automatic license plate recognition in indonesian plate, which have black background and white number

for use in linux just

Python Main.py -c directoryFileImage = calibrating the camera and threshold

Python Main.py   = use with cam

Python Main.py -i directoryFileImage = recognition an image

Python Main.py -v directoryFileVideo = recognition a video
